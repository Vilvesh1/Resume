package test;

/*
 * Vilvesh Srinivasan
 * CS 3443
 * Lab9
 * JUnit test cases for  methods in classes pertaining to Lab 9 assignment
 */

import hashmap.DualHashMap;
import org.junit.Test;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;



public class Lab9test {


@Test
public void getCOMPUTE(){

DualHashMap <String, String> dm = new DualHashMap <String, String>();
assertNull("Checking if object is null",dm.get(null));
}



@Test
public void reversegetCOMPUTE(){
DualHashMap <String, String> dm = new DualHashMap <String, String>();
assertNull("Checking if object is null",dm.reverseGet(null));
}




@Test
public void removeCOMPUTE(){
DualHashMap <String, String> dm = new DualHashMap <String, String>();
dm.remove(null,null);
assertNotNull("Checking if object is not null",dm);
}




@SuppressWarnings("null")
@Test

public void putCOMPUTE(){
DualHashMap <String, String> dm = null;
try {
dm.put(null,null);
}
catch(Exception e) {
}
assertNull("Checking if object is null",dm);
}




}