package test;

/*
 * Vilvesh Srinivasan
 * CS 3443
 * Lab8
 * JUnit test cases for  methods in classes pertaining to Lab 8 assignment
 */

import org.junit.Test;

import application.model.Calculator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;


public class Lab8test {


@Test(expected=NullPointerException.class)
public void updateCOMPUTE(){
Calculator c = new Calculator(); 
assertEquals("Checking if object is null",c.update(null),null);
}

@Test
public void getValueCOMPUTE(){
@SuppressWarnings("unused")
Calculator c = new Calculator(); 
assertNull("Checking if object is null", null);
}

}